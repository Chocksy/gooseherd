{{/*
=============================================================================
SERVICE TEMPLATE
This template renders a standard Kubernetes Service with common configuration.
=============================================================================
*/}}

{{- define "chart.service" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
{{- $serviceConfig := dig "service" dict $componentValues }}
{{- $ports := $componentValues.ports | default dict }}
{{- if not $ports }}
{{ fail "No ports defined for service. Please define at least one port in the component values." }}
{{- else }}

apiVersion: v1
kind: Service
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $serviceConfig | nindent 4 }}
spec:
  type: {{ dig "type" "ClusterIP" $serviceConfig }}
  ports:
  {{- range $name, $port := $ports }}
    {{- $servicePort := $port }}
    {{- $targetPort := $name }}
    {{- $protocol := "TCP" }}
    {{- if kindIs "map" $port }}
      {{- $servicePort = coalesce $port.servicePort $port.port $port.containerPort }}
      {{- $protocol = default "TCP" $port.protocol }}
      {{- if hasKey $port "targetPort" }}
        {{- $targetPort = $port.targetPort }}
      {{- else if hasKey $port "containerPort" }}
        {{- $targetPort = $port.containerPort }}
      {{- end }}
    {{- end }}
    {{- if not $servicePort }}
      {{- fail (printf "Port definition for %s must provide a numeric value (or servicePort/port/containerPort in map form)" $name) }}
    {{- end }}
    - name: {{ $name }}
      port: {{ $servicePort | int }}
      targetPort: {{ $targetPort }}
      protocol: {{ $protocol }}
      {{- if (and (eq (default "" $serviceConfig.type) "NodePort") $serviceConfig.nodePorts) }}
      nodePort: {{ index $serviceConfig.nodePorts $name }}
      {{- end }}
  {{- end }}
  selector: {{ include "common.labels" . | nindent 4 }}
  {{- with $serviceConfig.externalIPs }}
  externalIPs: {{ toYaml . | nindent 4 }}
  {{- end }}
  {{- with $serviceConfig.loadBalancerIP }}
  loadBalancerIP: {{ . }}
  {{- end }}
  {{- with $serviceConfig.loadBalancerSourceRanges }}
  loadBalancerSourceRanges: {{ toYaml . | nindent 4 }}
  {{- end }}
{{ end }}
{{- end }}

{{/*
Headless service template
Usage: {{ include "chart.service.headless" (dict "svc" "service-name" "cmp" "component" "Values" .Values) }}
*/}}
{{- define "chart.service.headless" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
{{- $serviceConfig := dig "service" "headless" dict $componentValues }}
{{- $ports := $componentValues.ports | default dict }}
{{- if not $ports }}
{{ fail "No ports defined for service. Please define at least one port in the component values." }}
{{- else }}

apiVersion: v1
kind: Service
metadata:
  name: {{ $cmp }}-headless
  labels:
    {{ include "common.labels" . | indent 4 }}
    service.kubernetes.io/headless: "true"
  {{ include "common.annotations" $serviceConfig | nindent 4 }}
spec:
  type: ClusterIP
  clusterIP: None
  ports:
  {{- range $name, $port := $componentValues.ports }}
    {{- $servicePort := $port }}
    {{- $targetPort := $name }}
    {{- $protocol := "TCP" }}
    {{- if kindIs "map" $port }}
      {{- $servicePort = coalesce $port.servicePort $port.port $port.containerPort }}
      {{- $protocol = default "TCP" $port.protocol }}
      {{- if hasKey $port "targetPort" }}
        {{- $targetPort = $port.targetPort }}
      {{- else if hasKey $port "containerPort" }}
        {{- $targetPort = $port.containerPort }}
      {{- end }}
    {{- end }}
    {{- if not $servicePort }}
      {{- fail (printf "Port definition for %s must provide a numeric value (or servicePort/port/containerPort in map form)" $name) }}
    {{- end }}
    - name: {{ $name }}
      port: {{ $servicePort | int }}
      targetPort: {{ $targetPort }}
      protocol: {{ $protocol }}
  {{- end }}
  selector: {{ include "common.labels" . | nindent 4 }}
  publishNotReadyAddresses: {{ default false $serviceConfig.publishNotReadyAddresses }}
{{ end }}
{{- end }}
