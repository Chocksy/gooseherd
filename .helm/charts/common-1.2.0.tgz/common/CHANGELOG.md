*# Changelog for Helm Common Library*
**1.2.0** (2026-02-25)
- Refactor common templates

**1.1.7** (2026-02-24)
- Update `common.job` helper

**1.1.6** (2026-02-13)
- Update PVC helper

**1.1.5** (2025-11-06)
- Updates to `common.affinity` & `common.tolerations` helpers

**1.1.4** (2025-10-29)
- Updates to `chart.extsecret` helper

**1.1.3** (2025-07-20)
- Upgrade `chart.extsecret`

**1.1.2** (2025-07-20)
- Remove global annotations from `chart.ingress` helper
- Update `chart.ingress` & `chart.service`

**1.1.1** (2025-05-12)
- Add `chart.statefulset` helper to manage StatefulSets

**1.1.0** (2024-12-11)
- Introduce full templating support for used components

**1.0.18** (2024-11-01)
- Make `common.probes` configurable with extra path

**1.0.17** (2024-06-12)
- Modify `secrets.retrieveOrGenerate` to handle optional value

**1.0.16** (2024-03-05)
- Add helper `secrets.retrieve.baseOrExternal`

**1.0.15** (2024-03-05)
- Add helper `secrets.retrieveOrDefine`

**1.0.14** (2024-03-05)
- Update helper `config.retrieveOrDefine` to work with NS

**1.0.13** (2024-03-05)
- Update helper `secrets.retrieve` to work with NS
- Update secrets helpers to have default secret name
