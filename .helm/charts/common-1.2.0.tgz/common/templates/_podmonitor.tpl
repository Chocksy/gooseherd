{{/*
=============================================================================
PODMONITOR TEMPLATES
This file contains templates for Prometheus Operator PodMonitor resources.
=============================================================================
*/}}

{{/*
Handle port selection for podMonitor
Uses explicit configuration if available, otherwise tries to smartly select a port
*/}}
{{- define "podMonitor.getMetricsPort" }}
{{- $componentValues := . }}
{{- $default := "metrics" }}

{{- if and $componentValues.podMonitor $componentValues.podMonitor.portName }}
  {{ $componentValues.podMonitor.portName }}
{{- else if and $componentValues.ports (hasKey $componentValues.ports "metrics") }}
  {{ $default }}
{{- else if and $componentValues.ports (hasKey $componentValues.ports "prometheus") }}
  {{ "prometheus" }}
{{- else if $componentValues.ports }}
  {{ keys $componentValues.ports | first }}
{{- else }}
  {{ $default }}
{{- end }}
{{- end }}

{{/*
Handle path selection for podMonitor
*/}}
{{- define "podMonitor.getMetricsPath" }}
{{- $componentValues := . }}
{{- if and $componentValues.podMonitor $componentValues.podMonitor.path }}
  {{ $componentValues.podMonitor.path }}
{{- else }}
  {{ "/metrics" }}
{{- end }}
{{- end }}

{{/*
Main PodMonitor template
*/}}
{{- define "chart.podmonitor" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
{{- $pmConfig := $componentValues.podMonitor }}

apiVersion: monitoring.coreos.com/v1
kind: PodMonitor
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{- with $componentValues.podMonitor.labels }}
    {{ toYaml . | nindent 4 }}
  {{- end }}
  {{ include "common.annotations" $pmConfig | nindent 4 }}
spec:
  selector:
    matchLabels: {{ include "common.labels" . | nindent 6 }}
    {{- with $componentValues.podMonitor.selectorMatchLabels }}
      {{ toYaml . | nindent 6 }}
    {{- end }}
  podMetricsEndpoints:
    - filterRunning: {{ default true $componentValues.podMonitor.filterRunning }}
      followRedirects: {{ default true $componentValues.podMonitor.followRedirects }}
      interval: {{ default "1m" $componentValues.podMonitor.interval }}
      path: {{ include "podMonitor.getMetricsPath" $componentValues }}
      port: {{ include "podMonitor.getMetricsPort" $componentValues | quote }}
      {{- with $componentValues.podMonitor.scheme }}
      scheme: {{ . }}
      {{- end }}
      {{- with $componentValues.podMonitor.scrapeTimeout }}
      scrapeTimeout: {{ . }}
      {{- end }}
      {{- with $componentValues.podMonitor.honorLabels }}
      honorLabels: {{ . }}
      {{- end }}
      {{- with $componentValues.podMonitor.honorTimestamps }}
      honorTimestamps: {{ . }}
      {{- end }}
      {{- with $componentValues.podMonitor.metricRelabelings }}
      metricRelabelings: {{ toYaml . | nindent 8 }}
      {{- else }}
      metricRelabelings:
        - action: drop
          regex: '(activerecord_query_duration_seconds_bucket|http_response_duration_milliseconds_bucket|rails_view_runtime_seconds_bucket|rails_request_duration_seconds_bucket|rails_db_runtime_seconds_bucket)'
          sourceLabels: [__name__]
      {{- end }}
      {{- with $componentValues.podMonitor.relabelings }}
      relabelings: {{ toYaml . | nindent 8 }}
      {{- end }}
      {{- with $componentValues.podMonitor.tlsConfig }}
      tlsConfig: {{ toYaml . | nindent 8 }}
      {{- end }}
  namespaceSelector:
    {{- with $componentValues.podMonitor.namespaceSelector }}
      {{ toYaml . | nindent 4 }}
    {{- else }}
    matchNames:
      - {{ $.Release.Namespace }}
    {{- end }}
  {{- with $componentValues.podMonitor.sampleLimit }}
  sampleLimit: {{ . }}
  {{- end }}
  {{- with $componentValues.podMonitor.targetLimit }}
  targetLimit: {{ . }}
  {{- end }}
  {{- with $componentValues.podMonitor.labelLimit }}
  labelLimit: {{ . }}
  {{- end }}
  {{- with $componentValues.podMonitor.labelNameLengthLimit }}
  labelNameLengthLimit: {{ . }}
  {{- end }}
  {{- with $componentValues.podMonitor.labelValueLengthLimit }}
  labelValueLengthLimit: {{ . }}
  {{- end }}
  {{- with $componentValues.podMonitor.jobLabel }}
  jobLabel: {{ . }}
  {{- end }}
  {{- with $componentValues.podMonitor.podTargetLabels }}
  podTargetLabels: {{ toYaml . | nindent 4 }}
  {{- end }}
  {{- with $componentValues.podMonitor.extraConfig }}
    {{ toYaml . | nindent 2 }}
  {{- end }}
{{- end -}}
