{{- define "chart.statefulset" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  annotations:
    {{ include "common.annotations.werf" . | nindent 4 }}
    {{- with $componentValues.annotations }}
    {{ toYaml . | nindent 4 }}
    {{- end }}
spec:
  serviceName: {{ default (printf "%s-headless" ($cmp)) $componentValues.serviceName | quote }}
  updateStrategy:
    type: {{ default "RollingUpdate" $componentValues.updateStrategy | quote }}
  podManagementPolicy: {{ default "OrderedReady" $componentValues.podManagementPolicy | quote }}
  minReadySeconds: {{ default 0 $componentValues.minReadySeconds }}
  {{- if not $componentValues.scaling }}
  replicas: {{ default 1 $componentValues.replicas | int }}
  {{- end }}
  selector:
    matchLabels: {{ include "common.labels" . | nindent 6 }}
  template:
    metadata:
      labels: {{ include "common.labels" . | nindent 8 }}
      {{- with $componentValues.podAnnotations }}
      annotations: {{ toYaml . | nindent 8 }}
      {{- end }}
    spec:
      {{ include "common.workload.podSpec" (dict
        "root" $
        "component" $componentValues
        "svc" $svc
        "cmp" $cmp
        "env" $env
        "includePorts" true
        "includeProbes" true
        "includeLifecycle" true
        "includePriorityClassName" true
        "includeHostAliases" true
        "includeTopologySpreadConstraints" true
        "includeTerminationGracePeriod" true
      ) | nindent 6 }}
  {{- with $componentValues.persistence }}
  volumeClaimTemplates:
    {{- range $vol := . }}
    - metadata:
        name: {{ required "Volume name is required" $vol.name }}
        labels: {{ include "common.labels" $ | nindent 10 }}
      spec: {{ include "common.pvc.spec" $vol | nindent 8 }}
    {{- end }}
  {{- end }}
{{- end }}
