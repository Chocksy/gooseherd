{{/*
=============================================================================
INGRESS TEMPLATES
This file contains templates for Kubernetes Ingress resources.
=============================================================================
*/}}

{{/*
Merge annotations for ingress
Combines global, component-specific, and type-specific annotations
*/}}
{{- define "ingress.annotations" -}}
{{- $conf := .conf }}
{{- $baseAnnotations := dig "annotations" dict $conf }}
{{- $typeAnnotations := dig .type "annotations" dict $conf }}
{{- if or $baseAnnotations $typeAnnotations }}
annotations:
{{ mergeOverwrite $baseAnnotations $typeAnnotations | toYaml | nindent 2 }}
{{- end }}
{{- end -}}

{{/*
Define a path for ingress
*/}}
{{- define "ingress.path" -}}
{{- $path := default "/" .path }}
{{- $pathType := default "ImplementationSpecific" .pathType }}
{{- $svcName := default .defaultSvc .svc | replace "_" "-" }}
{{- $svcPort := default "http" .port }}
path: {{ $path }}
pathType: {{ $pathType }}
backend:
  service:
    name: {{ $svcName }}
    port:
      {{- if kindIs "string" $svcPort }}
      name: {{ $svcPort }}
      {{- else }}
      number: {{ $svcPort }}
      {{- end }}
{{- end -}}

{{/*
Define rules for ingress
*/}}
{{- define "ingress.rules" -}}
{{- $conf := .conf }}
{{- $cmp := .cmp }}
rules:
{{- range $conf.domains }}
  - host: {{ if kindIs "map" . }}{{ .host }}{{ else }}{{ . }}{{ end }}
    http:
      paths:
      {{- if kindIs "map" . }}
        {{- range .paths }}
      - {{ include "ingress.path" (dict "path" .path "pathType" .pathType "svc" .svc "defaultSvc" $cmp "port" .port) | nindent 8 }}
        {{- end }}
      {{- else }}
      - {{ include "ingress.path" (dict "defaultSvc" $cmp) | nindent 8 }}
      {{- end }}
{{- end }}
{{- end -}}

{{/*
Generate TLS config for ingress
*/}}
{{- define "ingress.tls" -}}
{{- $conf := .conf }}
{{- $secretName := .secretName }}
tls:
  - hosts:
      {{- range $conf.domains }}
      - {{ if kindIs "map" . }}{{ .host }}{{ else }}{{ . }}{{ end }}
      {{- end }}
    secretName: {{ dig "tls" "secretName" $secretName $conf }}
{{- end -}}

{{/*
Main ingress template
*/}}
{{- define "chart.ingress" -}}
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $ingressValues := (index .Values (.cmp | replace "-" "_")).ingress }}

{{- if $ingressValues }}
{{- range $type, $conf := $ingressValues }}
{{ if and (not (eq $type "internal")) (not (eq $type "external")) }}
{{ continue }}
{{- else }}
{{- if $conf.domains }}
{{- $ingressName := printf "%s-%s-ingress" $cmp $type | replace "_" "-" }}
{{- $classNameDefault := get (dict "internal" "nginx-internal" "external" "nginx") $type }}

---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ $ingressName }}
  labels: {{ include "common.labels" $ | nindent 4 }}
  {{ include "ingress.annotations" (dict "conf" $ingressValues "type" $type) | nindent 2 }}
spec:
  ingressClassName: {{ dig "className" $classNameDefault $conf }}

  {{- if $conf.tls | default true }}
  {{ include "ingress.tls" (dict "conf" $conf "secretName" $ingressName) | nindent 2 }}
  {{- end }}
  {{ include "ingress.rules" (dict "conf" $conf "cmp" $cmp) | nindent 2 }}

  {{- with $conf.extraConfig }}
  {{ toYaml . | nindent 2 }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end -}}
