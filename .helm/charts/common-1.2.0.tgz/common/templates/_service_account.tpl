{{/*
=============================================================================
SERVICE ACCOUNT TEMPLATE
This template renders a Kubernetes ServiceAccount with annotations.
=============================================================================
*/}}

{{- define "chart.serviceAccount" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
{{- $saConfig := $componentValues.serviceAccount }}

apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ default $cmp $saConfig.name }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $saConfig | indent 4 }}
automountServiceAccountToken: {{ default true $saConfig.automount }}
{{- with $saConfig.imagePullSecrets }}
imagePullSecrets: {{ toYaml . | nindent 2 }}
{{- end }}
{{- with $saConfig.secrets }}
secrets: {{ toYaml . | nindent 2 }}
{{- end }}
{{- end }}
