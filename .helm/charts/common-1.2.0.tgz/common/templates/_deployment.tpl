{{/*
=============================================================================
DEPLOYMENT TEMPLATE
This template renders a standard Kubernetes Deployment with common boilerplate,
security contexts, probes, etc.
=============================================================================
*/}}

{{- define "chart.deployment" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  annotations:
  {{ include "common.annotations.werf" . | nindent 4 }}
  {{- with $componentValues.annotations }}
    {{ toYaml . | nindent 4 }}
  {{- end }}
  {{- if and (not $componentValues.replicas) (and ($componentValues.scaling) ($componentValues.scaling.min)) }}
    {{ printf "werf.io/replicas-on-creation: %s" ($componentValues.scaling.min | quote) | nindent 4 }}
  {{- end }}
spec:
  {{- if not $componentValues.scaling }}
  replicas: {{ default 1 $componentValues.replicas | int }}
  {{- end }}
  minReadySeconds: {{ default 10 $componentValues.minReadySeconds }}
  strategy:
    type: {{ default "RollingUpdate" $componentValues.strategyType }}
    {{- if eq (default "RollingUpdate" $componentValues.strategyType) "RollingUpdate" }}
    rollingUpdate:
      maxUnavailable: {{ default "25%" $componentValues.strategyMaxUnavailable }}
      maxSurge: {{ default "1" $componentValues.strategyMaxSurge }}
    {{- end }}
  selector:
    matchLabels: {{ include "common.labels" . | nindent 6 }}
  template:
    metadata:
      labels: {{ include "common.labels" . | nindent 8 }}
      {{- with $componentValues.podAnnotations }}
      annotations: {{ toYaml . | nindent 8 }}
      {{- end }}
    spec:
      {{ include "common.workload.podSpec" (dict
        "root" $
        "component" $componentValues
        "svc" $svc
        "cmp" $cmp
        "env" $env
        "includePorts" true
        "includeProbes" true
        "includeLifecycle" true
        "includePriorityClassName" true
        "includeHostAliases" true
        "includeTopologySpreadConstraints" true
        "includeTerminationGracePeriod" true
      ) | nindent 6 }}
{{- end }}
