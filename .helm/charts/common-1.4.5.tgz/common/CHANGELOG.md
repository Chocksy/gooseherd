*# Changelog for Helm Common Library*
**1.4.5** (2026-05-08)

- Fix `common.probes` so `probes.enabled: false` actually disables probes.
  Previous check used Sprig's `default true .probes.enabled`, which treats `false`
  as empty and silently flipped it back to `true`, leaving readiness/liveness
  probes rendered. Now resolved with `dig` so falsy-but-valid values are honored.
- Also accept `probes: false` (scalar) as a shorthand for disabling probes.

**1.4.4** (2026-05-03)

- Keep legacy pod/container `securityContext` defaults only under the
  Rails/Ruby profile. Generic, Python, and Go profiles now render
  `securityContext` only when it is set in values.
- Allow `global.securityContext.pod` / `global.securityContext.container` and
  component `securityContext` values to drive rendered security context fields.
- Stop auto-mounting every `volumes[]` entry as `/mnt/<name>`; only explicit
  `volumeMounts[]` and `persistence` entries now produce `volumeMounts`.

**1.4.3** (2026-05-03)

- Fix `common.affinity` for native Kubernetes affinity maps. Generic-profile
  charts like `pghero` now render configured `nodeAffinity` as-is instead of
  passing it through the legacy shorthand helper and emitting empty
  `matchExpressions[].key` values.
- Keep legacy shorthand affinity support for existing Rails-profile consumers.
- Render tolerations as native Kubernetes YAML for non-Rails profiles, so
  generic charts do not inherit Rails helper defaults.
- Add generic-profile smoke/golden coverage for native `affinity` and
  `tolerations`.

**1.4.2** (2026-05-03)

- Image resolution no longer reads `.Values.images.<component>` /
  `.Values.images.<component_name>`.
- Repository-only image maps now use `Chart.appVersion` as the container image
  tag.

**1.4.1** (2026-05-03)

Whitespace cleanup (no semantic changes — renders are identical to 1.4.0 once
trailing whitespace and empty `annotations: null` keys are normalized):
- Drop leading-newline body in `common.labels`, `common.labels.matchLabels`,
  `common.annotations`, `common.podAnnotations`, `common.annotations.werf`.
- Helpers now return clean content (no leading/trailing whitespace) so callers
  get tight output: `labels:\n    name: foo` instead of
  `labels: \n    \n    name: foo`.
- Caller pattern across all chart templates standardized to
  `key:\n  {{- include "..." | nindent N }}` (chomp + nindent).
- `common.workload.podSpec` rewritten with capture-trim per included helper —
  empty includes no longer emit blank-indented lines inside the container body
  (`command:`, `args:`, probes, securityContext, etc.).
- ConfigMap data range no longer emits 5-blank-line gap before the first key.
- `chart.binaryConfigmap` no longer emits a leading `---\n` empty document
  when no `binaryData` is configured.
- Empty `annotations:` blocks (when neither werf nor user annotations are set)
  are now omitted entirely on Deployment, StatefulSet, ServiceAccount,
  ConfigMap, Service, PDB, PVC, ScaledObject, etc.
- Probe blocks no longer have a blank line between `readinessProbe:` /
  `livenessProbe:` and the inner `httpGet:` / `tcpSocket:` block.
- Pod- and container-level `securityContext` blocks no longer have blank
  lines between fields.
- `imagePullSecrets:` and `volumeMounts:` lists no longer have a blank line
  before the first list item.
- Headless Service `labels:` indent fixed (was 8 spaces on first label,
  4 on the rest; now uniform 4 via `nindent`).

**1.4.0** (2026-04-29)

New resources:
- `chart.daemonset`
- `chart.hpa` (native HorizontalPodAutoscaler; mutually exclusive with KEDA `scaling`)
- `chart.vpa`
- `chart.networkpolicy` (per-component or top-level `networkPolicies:` map)
- `chart.secret` (native; top-level `nativeSecrets:` map)
- `chart.rbac` (Role/RoleBinding/ClusterRole/ClusterRoleBinding; per-component or top-level `rbac:`)
- `chart.servicemonitor` (Prometheus Operator)
- `chart.prometheusrule`
- `chart.priorityclass`
- `chart.triggerauth` (KEDA TriggerAuthentication / ClusterTriggerAuthentication)

Profiles:
- Add `global.profile` (rails | generic | python | go); default `rails` preserves every v1.3.1 default. Other profiles substitute vanilla K8s probe paths and drop Rails-specific PodMonitor metricRelabelings and envFrom phantom defaults. See `docs/profiles.md`.

Flexibility:
- Probes: `startupProbe`, separate `liveness`/`readiness` blocks, `grpc` probe type, `terminationGracePeriodSeconds`.
- Service: `sessionAffinity`/`sessionAffinityConfig`, `internalTrafficPolicy`/`externalTrafficPolicy` first-class, `ipFamilyPolicy`/`ipFamilies`, `publishNotReadyAddresses`, `clusterIP`, per-port `appProtocol`, `service.extraServices` for sibling Service objects.
- Deployment: `revisionHistoryLimit`, `progressDeadlineSeconds`, `paused`.
- StatefulSet: `persistentVolumeClaimRetentionPolicy`, `ordinals`, `revisionHistoryLimit`, per-VCT annotations.
- Job: `podFailurePolicy`, `suspend`, `manualSelector`, `selector`.
- CronJob: `jobTemplate.podFailurePolicy`.
- ConfigMap: `immutable`, `fromFiles`/`binaryFromFiles` glob loading.
- ExternalSecret: `dataFrom`, `target.template`.
- PVC: `accessModes` list form (in addition to scalar `accessMode`).
- PodMonitor: multi-endpoint shape (`endpoints[]`), `attachMetadata`, profile-driven `metricRelabelings`.
- ScaledObject: per-trigger `extraConfig`/`name`/`metricType`, `pausedReplicaCount` annotation.
- envFrom: phantom `config`/`secrets` defaults removed under non-rails profiles.
- Container security context: `seccompProfile.localhostProfile`, `procMount`, `seLinuxOptions`, `windowsOptions`.
- Pod: `dnsPolicy`/`dnsConfig`, `enableServiceLinks`, `shareProcessNamespace`, `runtimeClassName`, pod-level `automountServiceAccountToken`, `fsGroupChangePolicy`, `supplementalGroups`, `sysctls`, `hostNetwork`/`hostPID`/`hostIPC` first-class.
- Tolerations: `tolerationSeconds`; `Exists` operator without `key`.
- Image: `version` alias for `tag`; improved error messages.
- ServiceAccount: `serviceAccount.create: false` to bind without emitting; pod-level `common.serviceAccount` is profile-aware (omits literal `"default"` under non-rails).
- Ingress: `defaultBackend`, explicit `tls.hosts` override.
- PDB: `unhealthyPodEvictionPolicy`.

Tests:
- All v1.3.1 golden files unchanged (byte-identical renders for every existing consumer).
- New per-resource and per-profile golden files added (16 total smoke variants).

Breaking changes: none.

**1.3.1** (2026-04-26)
- Add `values.schema.json`; consumer charts now get `helm lint` validation of values shapes
- Add `registry` field support to image maps (`{registry, repository, tag}` -> `registry/repository:tag`)
- Add `global.compat.legacySelectorLabels` opt-in to keep `version` / `extraLabels` in selectors during 1.2 -> 1.3 migration (selectors are immutable)
- Add `global.deployment.replicasOnCreationAnnotation` to make the initial-replicas annotation key configurable
- Add `global.werf.annotations` explicit gate; werf annotations now default to on only when both `werf.name` and `werf.env` are set (not on any non-empty `werf.*`)
- Add `global.imagePullSecrets`; component-level `imagePullSecrets` falls back to it
- Ingress: list-style entries now respect `global.ingress.annotations`; map-style merges global + component-level + entry-level annotations
- Centralize `.Values` -> map conversion through a single private helper (`common._values`); add `common.cmp.dns` / `common.cmp.valuesKey` for component name munging; add `common.werf.annotationsEnabled` gate helper
- Tests: add `make golden-check` / `make golden-update` golden-file diff against committed renders, add a `values-features.yaml` smoke variant exercising the new surface
- CI: add `.github/workflows/helm-common-lint.yml` running `make lint` + `make golden-check` on PRs touching `helm/common/**`
- Docs: rewritten `docs/values-contract.md` with full reference table; expanded `docs/migration-from-werf.md` with selector-immutability and replicas-on-creation guidance

**1.3.0** (2026-02-27)
- Decouple chart helpers from hard `.Values.werf.*` requirements while preserving `werf` compatibility fallbacks
- Add generic app/environment/image resolution helpers for reusable internal app charts
- Generalize ingress generation for both map and list-style ingress configs
- Fix selector logic to use stable match-label helpers in workload/service/pdb/podmonitor resources
- Improve template robustness for probes, pod monitor port/path rendering, empty volume sections, and missing component maps
- Add local lint/smoke workflow (`Makefile` + `tests/smoke`) and example values files for generic and werf-legacy usage

**1.2.0** (2026-02-25)
- Refactor common templates

**1.1.7** (2026-02-24)
- Update `common.job` helper

**1.1.6** (2026-02-13)
- Update PVC helper

**1.1.5** (2025-11-06)
- Updates to `common.affinity` & `common.tolerations` helpers

**1.1.4** (2025-10-29)
- Updates to `chart.extsecret` helper

**1.1.3** (2025-07-20)
- Upgrade `chart.extsecret`

**1.1.2** (2025-07-20)
- Remove global annotations from `chart.ingress` helper
- Update `chart.ingress` & `chart.service`

**1.1.1** (2025-05-12)
- Add `chart.statefulset` helper to manage StatefulSets

**1.1.0** (2024-12-11)
- Introduce full templating support for used components

**1.0.18** (2024-11-01)
- Make `common.probes` configurable with extra path

**1.0.17** (2024-06-12)
- Modify `secrets.retrieveOrGenerate` to handle optional value

**1.0.16** (2024-03-05)
- Add helper `secrets.retrieve.baseOrExternal`

**1.0.15** (2024-03-05)
- Add helper `secrets.retrieveOrDefine`

**1.0.14** (2024-03-05)
- Update helper `config.retrieveOrDefine` to work with NS

**1.0.13** (2024-03-05)
- Update helper `secrets.retrieve` to work with NS
- Update secrets helpers to have default secret name
