{{/*
=============================================================================
POD DISRUPTION BUDGET TEMPLATE
This template renders a Kubernetes PodDisruptionBudget to manage disruptions
during voluntary disruptions like upgrades.
=============================================================================
*/}}

{{- define "chart.pdb" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}
{{- $pdbConfig := $componentValues.pdb | default dict }}

apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $pdbConfig | nindent 4 }}
spec:
  {{- if hasKey $pdbConfig "minAvailable" }}
  minAvailable: {{ $pdbConfig.minAvailable }}
  {{- else }}
  maxUnavailable: {{ coalesce $pdbConfig.maxUnavailable (dig "global" "pdb" "maxUnavailable" nil .Values) "25%" }}
  {{- end }}
  selector:
    matchLabels: {{ include "common.labels" . | nindent 6 }}
    {{- with $pdbConfig.selectorMatchLabels }}
      {{ toYaml . | indent 6 }}
    {{- end }}
{{- end -}}
