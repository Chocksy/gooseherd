# Migration from Werf-Centric Values

The chart now supports generic values while keeping `werf` compatibility
fallbacks. This guide walks through a safe rollout.

## Recommended Generic Values

Before (legacy):

```yaml
werf:
  name: my-app
  env: production
  image:
    app: ghcr.io/example/my-app:1.0.0
```

After (recommended):

```yaml
name: my-app
environment: production

global:
  image:
    repository: ghcr.io/example/my-app
    tag: "1.0.0"
```

If `tag`, `version`, and `digest` are omitted from an image map, the chart uses
`Chart.appVersion` as the tag.

Or per-component image:

```yaml
web:
  image:
    repository: ghcr.io/example/my-app-web
    tag: "1.0.0"
```

You can also use a structured map with separate registry/repository:

```yaml
global:
  image:
    registry: ghcr.io
    repository: example/my-app
    tag: "1.0.0"
```

## What Still Works

- `.Values.werf.name`
- `.Values.werf.env`
- `.Values.werf.image.app`
- `.Values.werf.image.pullPolicy`
- werf annotations (`werf.io/no-activity-timeout`,
  `werf.io/failures-allowed-per-replica`, `werf.io/replicas-on-creation`)
  -- emitted only when werf annotations are enabled (see below)

## Werf Annotations Gating

Pre-1.3, werf annotations were always emitted whenever `.Values.werf` had any
key set. The new behavior:

| Condition | werf annotations |
|-----------|------------------|
| `.Values.global.werf.annotations: true`  | on |
| `.Values.global.werf.annotations: false` | off |
| both `.Values.werf.name` and `.Values.werf.env` set | on (legacy default) |
| anything else (e.g. only `werf.image.app` for fallback) | off |

This prevents charts that keep `werf.image.app` only as an image-resolution
fallback from getting werf-specific Deployment annotations they didn't ask for.
If your chart sets `werf.name`/`werf.env`, behavior is unchanged.

## `werf.io/replicas-on-creation` Behavior Change

The annotation is now only emitted when werf annotations are enabled (see
table above). For charts mid-migration that drop `werf.*` while still relying
on the annotation to seed replicas at first install, set the key explicitly:

```yaml
global:
  deployment:
    replicasOnCreationAnnotation: "werf.io/replicas-on-creation"
```

Or, if you no longer use werf, configure it under your own annotation:

```yaml
global:
  deployment:
    replicasOnCreationAnnotation: "my.org/initial-replicas"
```

Set to empty string to disable entirely.

## Selector Immutability (Important)

Selectors on `Deployment` and `StatefulSet` are **immutable**: once a workload
exists, you cannot change `spec.selector.matchLabels` -- `helm upgrade` will
fail with `field is immutable`.

Pre-1.3 chart releases stored a wide selector set including
`app.kubernetes.io/version` and any `extraLabels`. The 1.3+ chart writes a
narrower stable selector (name, component, environment, instance only). For
**existing** workloads this means:

- If your prior release **did not** set `.version` and **did not** pass
  `extraLabels` to the helpers, no action needed -- selectors are unchanged.
- If your prior release **did** set either, opt into the legacy selector shape
  during migration:

```yaml
global:
  compat:
    legacySelectorLabels: true
```

Once all environments have been re-deployed (which requires deleting and
re-creating the workload, e.g. `kubectl delete deployment <name>
--cascade=orphan` then `helm upgrade`), you can drop the flag.

## Migration Steps

1. Move identity/env values to `name` and `environment` (or `global.*`).
2. Move image config to `global.image` or `<component>.image`.
3. Decide on werf annotations: keep the legacy-default behavior, or set
   `global.werf.annotations: false` once you've finished the move.
4. If you used `.version` or `extraLabels` previously, set
   `global.compat.legacySelectorLabels: true` on first 1.3+ deploy.
5. Render and compare:
   - `make lint`
   - `make lint-canarybot-compat` (if relevant)
   - `make golden-check` (catches accidental output drift)
6. Stage rollout per-environment.
7. Remove legacy `werf` keys after rollout verification. If your chart no
   longer needs `werf.io/replicas-on-creation`, set
   `global.deployment.replicasOnCreationAnnotation: ""` to suppress it.
