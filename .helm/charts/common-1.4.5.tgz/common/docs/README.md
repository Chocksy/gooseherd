# Common Helm Library Docs

This chart is a Helm **library** chart used to render reusable Kubernetes resources for internal apps.

## Contents

- [`usage.md`](./usage.md): how to use helpers in a consumer chart
- [`values-contract.md`](./values-contract.md): supported values and resolution rules
- [`migration-from-werf.md`](./migration-from-werf.md): moving from werf-centric values to generic values

## Quick Start

1. Add this chart as a dependency in your app chart.
2. Call the helpers from your templates (for example `chart.deployment`, `chart.service`, `chart.ingress`).
3. Provide component values under your component key (for example `web`, `worker`, `api`).

Minimal consumer template:

```yaml
{{- $cmp := "web" -}}
{{ include "chart.deployment" (merge (dict "cmp" $cmp) . ) }}
{{ include "chart.service" (merge (dict "cmp" $cmp) . ) }}
```

## Validation

- Library + smoke tests:
```bash
make lint
```

- Golden-file diff (catches accidental output drift):
```bash
make golden-check       # fail on drift
make golden-update      # accept drift after reviewing the diff
```

- Canarybot compatibility check:
```bash
make lint-canarybot-compat
```

- Schema: `values.schema.json` is shipped with the chart; consumer charts
  get `helm lint` validation for free. See `values-contract.md`.

