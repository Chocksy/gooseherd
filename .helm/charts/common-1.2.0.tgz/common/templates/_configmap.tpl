{{/*
=============================================================================
CONFIGMAP TEMPLATE
This template renders a Kubernetes ConfigMap with environment-specific configuration.

Usage: {{ include "chart.configmap" (dict "svc" "app-name" "cmp" "component" "Values" .Values) }}
=============================================================================
*/}}

{{- define "config.dict.common" }}{{- end }}
{{- define "config.dict.production" }}{{- end }}
{{- define "config.dict.staging" }}{{- end }}
{{- define "config.dict.review" }}{{- end }}
{{- define "config.dict.demo" }}{{- end }}
{{- define "config.dict.dev" }}{{- end }}
{{- define "config.dict.sandbox" }}{{- end }}

{{- define "config.annotations.default" }}
{{- if or (eq . "review") (eq . "demo") }}
helm.sh/hook: pre-install,pre-upgrade
helm.sh/hook-weight: "-5"
{{- else }}
werf.io/weight: "-1"
{{- end }}
{{- end }}

{{- define "chart.configmap" }}
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValue := index .Values (.cmp | replace "-" "_") }}

{{- if hasKey .Values "configs" }}
{{- range $name, $val := .Values.configs }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $name }}
  labels: {{ include "common.labels" $ | nindent 4 }}
  annotations: {{ include "config.annotations.default" $env | nindent 4 }}
data:
{{- range $key, $value := $val.data }}
{{ printf "%s: %s" $key (tpl (toString $value) $ | quote) | nindent 2 }}
{{- end }}
{{- end }}

{{- else }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  annotations: {{ include "config.annotations.default" $env | nindent 4 }}
data:
{{/* Include common config data for all environments */}}
{{- $commonConfig := include "config.dict.common" . | default "" | trim }}
{{- if ne $commonConfig "" }}
  {{ $commonConfig | nindent 2 }}
{{- end }}

{{/* Include environment-specific config data */}}
{{- $envSpecificTemplate := printf "config.dict.%s" $env }}
{{- $envConfig := include $envSpecificTemplate . | default "" | trim }}
{{- if ne $envConfig "" }}
  {{ $envConfig | nindent 2 }}
{{- end }}

{{/* Include component-specific configuration if available */}}
{{- if and (hasKey $componentValue "configmap") (hasKey $componentValue.configmap "data") }}
  {{- range $key, $value := $componentValue.configmap.data }}
  {{ $key }}: {{ tpl (toString $value) $ | quote }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create a ConfigMap specifically for binary data
Usage: {{ include "chart.binaryConfigmap" (dict "svc" "app-name" "cmp" "component" "Values" .Values) }}
*/}}
{{- define "chart.binaryConfigmap" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValue := index .Values (.cmp | replace "-" "_") }}

{{- if and (hasKey $componentValue "configmap") (hasKey $componentValue.configmap "binaryData") }}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $cmp }}-files
  labels: {{ include "common.labels" . | nindent 4 }}
  annotations: {{ include "config.annotations.default" $env | nindent 4 }}
binaryData:
  {{- range $key, $value := $componentValue.configmap.binaryData }}
  {{ $key }}: {{ $value | quote }}
  {{- end }}
{{- end }}
{{- end -}}
