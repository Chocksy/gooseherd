{{/*
=============================================================================
JOB TEMPLATE
This template renders a Kubernetes Job with common configuration.
=============================================================================
*/}}

{{- define "chart.job" }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values.jobs (.cmp | replace "-" "_") }}

apiVersion: batch/v1
kind: Job
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $componentValues | indent 2 }}
spec:
  backoffLimit: {{ default 0 $componentValues.backoffLimit | int }}
  {{- with $componentValues.activeDeadlineSeconds }}
  activeDeadlineSeconds: {{ . }}
  {{- end }}
  {{- with $componentValues.ttlSecondsAfterFinished }}
  ttlSecondsAfterFinished: {{ . }}
  {{- end }}
  {{- with $componentValues.completions }}
  completions: {{ . }}
  {{- end }}
  {{- with $componentValues.parallelism }}
  parallelism: {{ . }}
  {{- end }}
  {{- with $componentValues.completionMode }}
  completionMode: {{ . }}
  {{- end }}
  template:
    metadata:
      labels: {{ include "common.labels" . | nindent 8 }}
      {{ include "common.podAnnotations" $componentValues | indent 6 }}
    spec:
      {{ include "common.workload.podSpec" (dict
        "root" $
        "component" $componentValues
        "svc" $svc
        "cmp" $cmp
        "env" $env
        "includePriorityClassName" true
        "restartPolicy" (default "Never" $componentValues.restartPolicy)
      ) | nindent 6 }}
{{- end }}
