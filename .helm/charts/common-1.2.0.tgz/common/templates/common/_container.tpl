{{/*
=============================================================================
CONTAINER CONFIGURATION HELPERS
=============================================================================
*/}}

{{/*
Process container command
Usage: {{ include "common.command" .Values.myComponent }}
*/}}
{{- define "common.command" }}
{{- if kindIs "map" . }}
{{- if hasKey . "command" }}
{{- with .command }}
command: {{ . | toYaml | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Process container args
Usage: {{ include "common.args" .Values.myComponent }}
*/}}
{{- define "common.args" }}
{{- if kindIs "map" . }}
{{- if hasKey . "args" }}
{{- with .args }}
args: {{ . | toYaml | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Process container resources
Usage: {{ include "common.resources" .Values.myComponent }}
*/}}
{{- define "common.resources" }}
{{- if kindIs "map" . }}
{{- if hasKey . "resources" }}
{{- with .resources }}
resources: {{ . | toYaml | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Process container lifecycle
Usage: {{ include "common.lifecycle" .Values.myComponent }}
*/}}
{{- define "common.lifecycle" }}
{{- if kindIs "map" . }}
{{- if hasKey . "lifecycle" }}
{{- with .lifecycle }}
lifecycle: {{ . | toYaml | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Process ports for containers
Usage: {{ include "common.ports" .Values.myComponent }}
*/}}
{{- define "common.ports" }}
{{- if kindIs "map" . }}
{{- if hasKey . "ports" }}
ports:
{{- range $name, $value := .ports }}
{{- if kindIs "map" $value }}
- name: {{ $name }}
  containerPort: {{ $value.containerPort | int }}
  protocol: {{ default "TCP" $value.protocol }}
  {{- with $value.hostPort }}
  hostPort: {{ . }}
  {{- end }}
{{- else }}
- name: {{ $name }}
  containerPort: {{ $value | int }}
  protocol: TCP
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
=============================================================================
PROBE HELPERS
=============================================================================
*/}}

{{/*
Define a probe with intelligent defaults
Usage: {{ include "common.probe" .Values.myComponent }}
*/}}
{{- define "common.probe" }}
{{- $probe := dict }}
{{- $_ := set $probe "type" "http" }}
{{- $_ = set $probe "path" "/health_check/full" }}
{{- $_ = set $probe "command" (list "cat" "/app/tmp/sidekiq_readiness_probe") }}
{{- $_ = set $probe "port" "http" }}
{{- $_ = set $probe "initialDelaySeconds" 0 }}
{{- $_ = set $probe "periodSeconds" 10 }}
{{- $_ = set $probe "failureThreshold" 5 }}
{{- $_ = set $probe "timeoutSeconds" 3 }}

{{- if hasKey . "probes" }}
{{- $_ := set $probe "type" (default $probe.type .probes.type) }}
{{- $_ = set $probe "path" (default $probe.path .probes.path) }}
{{- $_ = set $probe "command" (default $probe.command .probes.command) }}
{{- $_ = set $probe "port" (default $probe.port .probes.port) }}
{{- $_ = set $probe "initialDelaySeconds" (default $probe.initialDelaySeconds .probes.initialDelaySeconds) }}
{{- $_ = set $probe "periodSeconds" (default $probe.periodSeconds .probes.periodSeconds) }}
{{- $_ = set $probe "failureThreshold" (default $probe.failureThreshold .probes.failureThreshold) }}
{{- $_ = set $probe "timeoutSeconds" (default $probe.timeoutSeconds .probes.timeoutSeconds) }}
{{- end }}

{{- if eq $probe.type "exec" }}
exec:
  command: {{ toYaml $probe.command | nindent 4 }}
{{- else if eq $probe.type "http" }}
httpGet:
  path: {{ $probe.path }}
  port: {{ $probe.port }}
  {{- with .probes.httpHeaders }}
  httpHeaders: {{ toYaml . | nindent 4 }}
  {{- end }}
{{- else if eq $probe.type "tcp" }}
tcpSocket:
  port: {{ $probe.port }}
{{- end }}
initialDelaySeconds: {{ $probe.initialDelaySeconds }}
periodSeconds: {{ $probe.periodSeconds }}
failureThreshold: {{ $probe.failureThreshold }}
timeoutSeconds: {{ $probe.timeoutSeconds }}
{{- with .probes.successThreshold }}
successThreshold: {{ . }}
{{- end }}
{{- end }}

{{/*
Configure both liveness and readiness probes using common settings
Can be disabled with probes.enabled=false
Usage: {{ include "common.probes" .Values.myComponent }}
*/}}
{{- define "common.probes" }}
{{- if and (.probes) (eq .probes.enabled false) }}
{{ else }}
readinessProbe: {{ include "common.probe" . | nindent 2 }}
livenessProbe: {{ include "common.probe" . | nindent 2 }}
{{ end }}
{{- end }}

{{/*
=============================================================================
ENVIRONMENT VARIABLES AND REFERENCES
=============================================================================
*/}}

{{/*
Define a secret reference environment variable
Usage: {{ include "common.env.secretRef" (dict "name" "DB_PASSWORD" "secretName" "my-secret" "key" "password") }}
*/}}
{{- define "common.env.secretRef" }}
  - name: {{ .name }}
    valueFrom:
      secretKeyRef:
        name: {{ .secretName }}
        key: {{ .key }}
        {{- with .optional }}
        optional: {{ . }}
        {{- end }}
{{- end }}

{{/*
Define a configmap reference environment variable
Usage: {{ include "common.env.configMapRef" (dict "name" "LOG_LEVEL" "configMapName" "app-config" "key" "log-level") }}
*/}}
{{- define "common.env.configMapRef" }}
  - name: {{ .name }}
    valueFrom:
      configMapKeyRef:
        name: {{ .configMapName }}
        key: {{ .key }}
        {{- with .optional }}
        optional: {{ . }}
        {{- end }}
{{- end }}

{{/*
Define a field reference environment variable
Usage: {{ include "common.env.fieldRef" (dict "name" "POD_NAME" "fieldPath" "metadata.name") }}
*/}}
{{- define "common.env.fieldRef" }}
  - name: {{ .name }}
    valueFrom:
      fieldRef:
        fieldPath: {{ .fieldPath }}
{{- end }}

{{/*
Process environment variables from a dictionary
Usage: {{ include "common.envs" .Values.myComponent }}
*/}}
{{- define "common.envs" }}
{{- if kindIs "map" . }}
{{- if hasKey . "env" }}
env:
{{- range $key, $value := .env }}
{{- if kindIs "map" $value }}
{{- if hasKey $value "valueFrom" }}
- name: {{ $key }}
  valueFrom: {{ toYaml $value.valueFrom | nindent 4 }}
{{- else }}
- name: {{ $key }}
  value: {{ tpl (toString $value.value) $ | quote }}
{{- end }}
{{- else }}
- name: {{ $key }}
  value: {{ tpl (toString $value) $ | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
EnvFrom helper supporting both global and component-specific configs/secrets
Usage: {{ include "common.envFrom" (dict "svc" .Values.myComponent "global" .Values.global) }}
*/}}
{{- define "common.envFrom" }}
{{- $entries := list }}

{{/* Append global defaults/config where present */}}
{{- if and (kindIs "map" .global) (hasKey .global "envFrom") }}
  {{- with .global.envFrom }}
    {{- range .configs | default (list (dict "name" "config")) }}
      {{- if kindIs "string" . }}
        {{- $entries = append $entries (dict "type" "configMapRef" "name" .) }}
      {{- else }}
        {{- $entry := dict "type" "configMapRef" "name" .name }}
        {{- if hasKey . "optional" }}
          {{- $_ := set $entry "optional" .optional }}
        {{- end }}
        {{- $entries = append $entries $entry }}
      {{- end }}
    {{- end }}
    {{- range .secrets | default (list (dict "name" "secrets")) }}
      {{- if kindIs "string" . }}
        {{- $entries = append $entries (dict "type" "secretRef" "name" .) }}
      {{- else }}
        {{- $entry := dict "type" "secretRef" "name" .name }}
        {{- if hasKey . "optional" }}
          {{- $_ := set $entry "optional" .optional }}
        {{- end }}
        {{- $entries = append $entries $entry }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}

{{/* Append component-specific entries */}}
{{- if and (kindIs "map" .svc) (hasKey .svc "envFrom") }}
  {{- with .svc.envFrom }}
    {{- range .configs | default (list) }}
      {{- if kindIs "string" . }}
        {{- $entries = append $entries (dict "type" "configMapRef" "name" .) }}
      {{- else }}
        {{- $entry := dict "type" "configMapRef" "name" .name }}
        {{- if hasKey . "optional" }}
          {{- $_ := set $entry "optional" .optional }}
        {{- end }}
        {{- $entries = append $entries $entry }}
      {{- end }}
    {{- end }}
    {{- range .secrets | default (list) }}
      {{- if kindIs "string" . }}
        {{- $entries = append $entries (dict "type" "secretRef" "name" .) }}
      {{- else }}
        {{- $entry := dict "type" "secretRef" "name" .name }}
        {{- if hasKey . "optional" }}
          {{- $_ := set $entry "optional" .optional }}
        {{- end }}
        {{- $entries = append $entries $entry }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}

{{- if gt (len $entries) 0 }}
envFrom:
{{- range $entry := $entries }}
  - {{ $entry.type }}:
      name: {{ $entry.name | quote }}
      {{- if hasKey $entry "optional" }}
      optional: {{ $entry.optional }}
      {{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Container security context that can be applied to all containers with intelligent defaults
Reads from .securityContext.container if available, uses provided defaults if not
Usage:
- Simple: {{ include "common.container.securityContext" . }}
- With overrides: {{ include "common.container.securityContext" (dict "readOnlyRootFilesystem" true) }}
*/}}
{{- define "common.container.securityContext" }}
{{- $secCtx := dict }}
{{- $defaults := dict "allowPrivilegeEscalation" false "runAsNonRoot" true }}

{{/* Get values from .securityContext.container if available */}}
{{- if . }}
  {{- if kindIs "map" . }}
    {{- if hasKey . "securityContext" }}
      {{- if hasKey .securityContext "container" }}
        {{- $secCtx = .securityContext.container }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}

securityContext:
  {{/* allowPrivilegeEscalation with proper fallbacks */}}
  allowPrivilegeEscalation: {{ default (default $defaults.allowPrivilegeEscalation $secCtx.allowPrivilegeEscalation) .allowPrivilegeEscalation }}

  {{/* runAsNonRoot with proper fallbacks */}}
  runAsNonRoot: {{ default (default $defaults.runAsNonRoot $secCtx.runAsNonRoot) .runAsNonRoot }}

  {{/* privileged with fallbacks */}}
  {{- $privileged := default $secCtx.privileged .privileged }}
  {{- if not (kindIs "invalid" $privileged) }}
  privileged: {{ $privileged }}
  {{- end }}

  {{/* readOnlyRootFilesystem with fallbacks */}}
  {{- $readOnlyRootFilesystem := default $secCtx.readOnlyRootFilesystem .readOnlyRootFilesystem }}
  {{- if not (kindIs "invalid" $readOnlyRootFilesystem) }}
  readOnlyRootFilesystem: {{ $readOnlyRootFilesystem }}
  {{- end }}

  {{/* capabilities with fallbacks */}}
  {{- $capabilities := default $secCtx.capabilities .capabilities }}
  {{- if $capabilities }}
  capabilities: {{ toYaml $capabilities | nindent 4 }}
  {{- end }}
{{- end }}

{{/*
Process and render volumeMounts for containers
Automatically maps to volumes defined in the same component
Usage: {{ include "common.volumeMounts" .Values.myComponent }}
*/}}
{{- define "common.volumeMounts.spec" }}
- name: {{ required "Volume name is required" .name }}
  {{- if hasKey . "mountPath" }}
  mountPath: {{ .mountPath }}
  {{- else }}
  mountPath: /mnt/{{ .name }}
  {{- end }}
  {{- if hasKey . "subPath" }}
  subPath: {{ .subPath }}
  {{- end }}
  {{- if hasKey . "readOnly" }}
  readOnly: {{ .readOnly }}
  {{- end }}
{{- end }}

{{- define "common.volumeMounts" }}
{{- if kindIs "map" . }}
volumeMounts:
{{- if hasKey . "volumes" }}
{{- range $volume := .volumes }}
{{ include "common.volumeMounts.spec" $volume | nindent 2 }}
{{- end }}
{{- end }}
{{- if hasKey . "volumeMounts" }}
{{- range $volumeMount := .volumeMounts }}
{{ include "common.volumeMounts.spec" $volumeMount | nindent 2 }}
{{- end }}
{{- end }}
{{- if hasKey . "persistence" }}
{{- $persistence := .persistence }}
{{- if kindIs "map" $persistence }}
{{ include "common.volumeMounts.spec" $persistence | nindent 2 }}
{{- else if kindIs "slice" $persistence }}
{{- range $pvc := $persistence }}
{{ include "common.volumeMounts.spec" $pvc | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
