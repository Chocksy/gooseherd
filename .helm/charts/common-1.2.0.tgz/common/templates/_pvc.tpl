{{/*
=============================================================================
PERSISTENT VOLUME CLAIM TEMPLATE
This template renders Kubernetes PersistentVolumeClaims for components.
=============================================================================
*/}}

{{- define "chart.pvc" }}
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values (.cmp | replace "-" "_") }}

{{- if not (hasKey $componentValues "persistence") }}
  {{- if .Debug }}
    {{ fail (printf "Component %s does not have persistence configuration" $cmp) }}
  {{- else }}
    {{ print (printf "Skipping PVC for component '%s': no persistence defined" $cmp) | quote | printf "# %s" }}
  {{- end }}
{{- else }}
  {{- $persistence := $componentValues.persistence }}
  {{- if kindIs "map" $persistence }}
---
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: {{ default $cmp $persistence.name }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $persistence | nindent 4 }}
spec:
  {{ include "common.pvc.spec" $persistence | nindent 4 }}

  {{- else if kindIs "slice" $persistence }}
    {{- range $pvc := $persistence }}
---
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: {{ required "PVC name is required" $pvc.name }}
  labels: {{ include "common.labels" $ | nindent 4 }}
  {{ include "common.annotations" $pvc | nindent 4 }}
spec:
  {{ include "common.pvc.spec" $pvc | nindent 4 }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end }}
