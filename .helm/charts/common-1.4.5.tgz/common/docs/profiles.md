# Profiles

`global.profile` selects a set of defaults that have historically been
hardcoded into the library. The `rails` profile is the default and preserves
all v1.3.1 behavior.

```yaml
global:
  profile: rails        # default; or generic | python | go
```

## Defaults table

| Field | rails (default) | generic | python | go |
|---|---|---|---|---|
| `probe.path` | `/health_check/full` | `/healthz` | `/health` | `/healthz` |
| `probe.command` (exec) | `[cat, /app/tmp/sidekiq_readiness_probe]` | — | — | — |
| `probe.failureThreshold` | 5 | 3 | 3 | 3 |
| `probe.timeoutSeconds` | 3 | 1 | 2 | 1 |
| `probe.port` | http | http | http | http |
| `probe.initialDelaySeconds` | 0 | 0 | 0 | 0 |
| `probe.periodSeconds` | 10 | 10 | 10 | 10 |
| `podMonitor.metricRelabelings` | Rails-specific drops | `[]` | `[]` | `[]` |
| `envFrom.defaultConfigName` | `config` | `""` | `""` | `""` |
| `envFrom.defaultSecretName` | `secrets` | `""` | `""` | `""` |
| `service.type` | ClusterIP | ClusterIP | ClusterIP | ClusterIP |
| `pvc.storageClass` | gp3 | gp3 | gp3 | gp3 |
| `pvc.accessMode` | ReadWriteOnce | ReadWriteOnce | ReadWriteOnce | ReadWriteOnce |
| `securityContext.pod` | runAsUser 1000, runAsGroup 3000, RuntimeDefault seccomp | values only | values only | values only |
| `securityContext.container` | allowPrivilegeEscalation false, runAsNonRoot true | values only | values only | values only |

The Rails profile's `metricRelabelings` drops these series:

- `activerecord_query_duration_seconds_bucket`
- `http_response_duration_milliseconds_bucket`
- `rails_view_runtime_seconds_bucket`
- `rails_request_duration_seconds_bucket`
- `rails_db_runtime_seconds_bucket`

## Override priority

Per profile-resolved field, the resolution order is:

1. `<component>.<helper>.<key>` — explicit per-component override (highest).
2. `.Values.global.<helper>.<key>` — chart-wide override of the profile default.
3. profile default (lowest).

So setting `global.profile: generic` and then `web.probes.path: /custom`
gives you `/custom` for web's probe path, with all other web defaults
coming from `generic`.

## Migrating an existing chart from rails to generic

The rails profile is the default for backward compatibility. To migrate
a chart so its renders match its current 1.3.x output but the profile is
explicitly `generic`, override the fields the rails profile sets:

```yaml
global:
  profile: generic
  securityContext:
    pod:
      runAsUser: 1000
      runAsGroup: 3000
      seccompType: RuntimeDefault
    container:
      allowPrivilegeEscalation: false
      runAsNonRoot: true
  probe:
    path: /health_check/full
    failureThreshold: 5
    timeoutSeconds: 3
  envFrom:
    configs: [{ name: config }]
    secrets: [{ name: secrets }]
# componentValues.podMonitor.metricRelabelings stays the rails list per-component.
```

In practice it is usually simpler to keep the `rails` profile until you
intentionally want to adopt `generic` defaults across the chart.
