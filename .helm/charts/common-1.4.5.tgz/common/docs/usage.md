# Usage

## 1) Add Dependency

```yaml
dependencies:
  - name: common
    version: "^1.4.0"
    repository: "s3://hubstaff-internal-helm-charts"
```

## 2) Render Resources from Your Templates

Example (`templates/deployment.yaml` in consumer chart):

```yaml
{{- $cmp := "web" -}}
{{ include "chart.deployment" (merge (dict "cmp" $cmp) . ) }}
{{ include "chart.serviceAccount" (merge (dict "cmp" $cmp) . ) }}
{{ include "chart.service" (merge (dict "cmp" $cmp) . ) }}
{{ include "chart.ingress" (merge (dict "cmp" $cmp) . ) }}
```

You can also use:
- `chart.statefulset`
- `chart.service.headless`
- `chart.pvc`
- `chart.job`
- `chart.cronjob`
- `chart.pdb`
- `chart.podmonitor`
- `chart.scaledobject`
- `chart.configmap`
- `chart.binaryConfigmap`
- `chart.extsecret`
- `chart.daemonset` *(1.4)*
- `chart.hpa` *(1.4 — native HPA, mutually exclusive with KEDA `scaling`)*
- `chart.vpa` *(1.4)*
- `chart.networkpolicy` *(1.4)*
- `chart.secret` *(1.4 — native K8s Secret)*
- `chart.rbac` *(1.4 — Role/RoleBinding/ClusterRole/ClusterRoleBinding)*
- `chart.servicemonitor` *(1.4 — Prometheus Operator)*
- `chart.prometheusrule` *(1.4)*
- `chart.priorityclass` *(1.4)*
- `chart.triggerauth` *(1.4 — KEDA TriggerAuthentication)*

## 3) Provide Component Values

Example:

```yaml
name: internal-app
environment: staging

web:
  replicas: 2
  image:
    repository: ghcr.io/example/web
    tag: "2.0.0"
  ports:
    http: 8080
  ingress:
    external:
      domains:
        - app.example.com
```

See full examples:
- `examples/values.generic.yaml`
- `examples/values.werf-legacy.yaml`

## Lint and Render

```bash
make lint
```

