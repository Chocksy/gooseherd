{{/*
=============================================================================
COMMON HELM TEMPLATES
Core library of common Kubernetes template helpers for consistent application deployment.
=============================================================================
*/}}

{{/*
=============================================================================
LABEL AND ANNOTATION HELPERS
=============================================================================
*/}}

{{/*
Common labels that should be applied to all resources.
Includes standard Kubernetes recommended labels.
Usage: {{ include "common.labels" (dict "svc" "my-service" "cmp" "web" "env" "prod" "Values" .Values) }}
*/}}
{{- define "common.labels" }}
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := default "" .cmp }}
{{- $env := default .Values.werf.env .env }}
app.kubernetes.io/name: {{ $svc }}
{{- if $cmp }}
app.kubernetes.io/component: {{ $cmp }}
{{- end }}
app.kubernetes.io/environment: {{ $env }}
{{- if .release }}
app.kubernetes.io/instance: {{ .release }}
{{- else if .Release }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
{{- with .version }}
app.kubernetes.io/version: {{ . | quote }}
{{- end }}
{{- with .extraLabels }}
{{ toYaml . | nindent 0 }}
{{- end }}
{{- end }}

{{/*
MatchLabels to be used in selectors
Usage: {{ include "common.labels.matchLabels" (dict "svc" "my-service" "cmp" "web" "env" "prod" "Values" .Values) }}
*/}}
{{- define "common.labels.matchLabels" }}
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := default "" .cmp }}
{{- $env := default .Values.werf.env .env }}
app.kubernetes.io/name: {{ $svc }}
{{- if $cmp }}
app.kubernetes.io/component: {{ $cmp }}
{{- end }}
app.kubernetes.io/environment: {{ $env }}
{{- with .extraLabels }}
{{ toYaml . | nindent 0 }}
{{- end }}
{{- end }}

{{/*
Werf-specific deployment/job annotations
*/}}
{{- define "common.annotations.werf" }}
werf.io/no-activity-timeout: {{ default "6m" .timeout | quote }}
werf.io/failures-allowed-per-replica: {{ default "3" .failures | quote }}
{{- end }}

{{/*
Process annotations from a dictionary or nested structure
Usage: {{ include "common.annotations" .Values.myComponent.annotations }}
*/}}
{{- define "common.annotations" }}
{{- if kindIs "map" . }}
{{- if hasKey . "annotations" }}
{{- with .annotations }}
annotations: {{ . | toYaml | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
=============================================================================
TEMPLATE UTILITY HELPERS
=============================================================================
*/}}

{{/*
Safely render a template with a default value
Usage: {{ include "common.renderTemplateOrDefault" (dict "name" "my-template" "context" $ "default" "default-value") }}
*/}}
{{- define "common.renderTemplateOrDefault" }}
{{- $result := include .name .context | trim }}
{{- if $result }}
{{ $result }}
{{- else }}
{{ .default }}
{{- end }}
{{- end }}

{{/*
Generate a random string with a prefix and optional separator
Usage: {{ include "common.generateName" (dict "prefix" "app" "separator" "-" "length" 8) }}
*/}}
{{- define "common.generateName" }}
{{- $prefix := default "" .prefix }}
{{- $separator := default "-" .separator }}
{{- $length := default 8 .length }}
{{- if $prefix }}
{{ printf "%s%s%s" $prefix $separator (randAlphaNum $length | lower) }}
{{- else }}
{{ randAlphaNum $length | lower }}
{{- end }}
{{- end }}

{{/*
Format a value based on its type
Usage: {{ include "common.format" (dict "value" .Values.someValue "type" "json") }}
*/}}
{{- define "common.format" }}
{{- $value := .value }}
{{- $type := default "yaml" .type }}
{{- if eq $type "json" }}
{{ $value | toJson }}
{{- else if eq $type "raw" }}
{{ $value }}
{{- else }}
{{ $value | toYaml }}
{{- end }}
{{- end }}

{{/*
Deep merge maps
Usage: {{ include "common.mergeValues" (dict "src" $srcMap "dest" $destMap) }}
*/}}
{{- define "common.mergeValues" }}
{{- $src := .src }}
{{- $dest := .dest }}
{{ toYaml (merge $dest $src) }}
{{- end }}

{{/*
=============================================================================
SPECIALIZED HELPERS
=============================================================================
*/}}

{{/*
Format an HTTP URL with protocol, host and optional path
Usage: {{ include "common.formatUrl" (dict "protocol" "http" "host" "example.com" "path" "/api/v1") }}
*/}}
{{- define "common.formatUrl" }}
{{- $protocol := default "http" .protocol }}
{{- $host := .host }}
{{- $path := default "" .path }}
{{- if and $host $protocol }}
{{ printf "%s://%s%s" $protocol $host $path }}
{{- else }}
{{ fail "Host is required for URL formatting" }}
{{- end }}
{{- end }}

{{/*
Format a database URL from components
Usage: {{ include "common.dbUrl" (dict "type" "postgres" "host" "db.example.com" "port" "5432" "name" "mydb" "user" "dbuser" "password" "secret") }}
*/}}
{{- define "common.dbUrl" }}
{{- $type := default "postgres" .type }}
{{- $host := .host }}
{{- $port := .port }}
{{- $name := .name }}
{{- $user := .user }}
{{- $password := .password }}
{{- $options := default "" .options }}
{{- if and $host $name }}
{{- if and $user $password }}
{{ printf "%s://%s:%s@%s:%s/%s%s" $type $user $password $host $port $name $options }}
{{- else }}
{{ printf "%s://%s:%s/%s%s" $type $host $port $name $options }}
{{- end }}
{{- else }}
{{ fail "Host and database name are required for DB URL formatting" }}
{{- end }}
{{- end }}

{{/*
Generate a DNS-safe name
Usage: {{ include "common.safeName" (dict "name" "my.service-name_here" "maxLength" 63) }}
*/}}
{{- define "common.safeName" }}
{{- $name := .name | lower | replace "." "-" | replace "_" "-" | trunc (default 63 .maxLength) | trimSuffix "-" }}
{{ $name }}
{{- end }}

{{/*
Indent multiline strings with a specified number of spaces
Usage: {{ include "common.indent" (dict "value" $multilineString "spaces" 2) }}
*/}}
{{- define "common.indent" }}
{{- $lines := splitList "\n" .value }}
{{- $spaces := default 2 .spaces | int }}
{{- $indent := "" }}
{{- range $i, $_ := until $spaces }}
  {{- $indent = printf "%s " $indent }}
{{- end }}
{{- range $i, $line := $lines }}
  {{- if $i }}
    {{ printf "\n%s%s" $indent $line }}
  {{- else }}
    {{ $line }}
  {{- end }}
{{- end }}
{{- end }}
