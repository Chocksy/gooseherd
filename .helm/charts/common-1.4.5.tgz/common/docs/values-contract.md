# Values Contract

This document is the source of truth for the values shapes consumed by the
`common` library chart. The chart ships a `values.schema.json` that encodes
the same contract; consumer charts get `helm lint` validation for free.

## Identity and Environment Resolution

App name (`app.kubernetes.io/name`) resolution order:
1. `.svc` from helper call
2. `.Values.global.name`
3. `.Values.app.name`
4. `.Values.name`
5. `.Values.werf.name` (legacy fallback)
6. `.Chart.Name`
7. `"app"`

Environment (`app.kubernetes.io/environment`) resolution order:
1. `.env` from helper call
2. `.Values.global.environment`
3. `.Values.global.env`
4. `.Values.environment`
5. `.Values.env`
6. `.Values.werf.env` (legacy fallback)
7. `"default"`

## Profiles

Profiles encode previously-hardcoded library defaults so that non-Rails
apps don't have to opt out per field. See [profiles.md](profiles.md) for
the full table.

`global.profile` accepts `rails` (default — preserves v1.3.1 behavior),
`generic`, `python`, or `go`.

Override priority for any profile-resolved field:

1. `<component>.<helper>.<key>` — per-component (highest).
2. `.Values.global.<helper>.<key>` — chart-wide.
3. profile default (lowest).

`securityContext` is profile-aware: the default `rails` profile emits the
legacy pod/container defaults, while `generic`, `python`, and `go` render
security context only from `.Values.global.securityContext` or the component's
own `securityContext`.

## Image Resolution

Container image resolution order:
1. `<component>.image`
2. `.Values.global.image`
3. `.Values.werf.image.app` (legacy fallback)
4. `.Chart.AppVersion`, as the tag for repository-only image maps

Supported image map shapes (any of these resolve to a string image reference):

| Shape | Result |
|-------|--------|
| `"ghcr.io/foo/bar:1.0"` | used as-is |
| `{ image: "..." }` | `image` used as-is |
| `{ repository, tag }` | `repository:tag` |
| `{ repository, digest }` | `repository@digest` |
| `{ registry, repository, tag }` | `registry/repository:tag` |
| `{ name, tag }` | alias of `repository` |

When an image map has only `repository` or `name`, `Chart.appVersion` becomes
the tag.

`imagePullPolicy` resolution order:
1. `<component>.imagePullPolicy`
2. `<component>.image.pullPolicy`
3. `.Values.global.imagePullPolicy`
4. `.Values.global.image.pullPolicy`
5. `.Values.werf.image.pullPolicy` (legacy fallback)
6. `"IfNotPresent"`

`imagePullSecrets` resolution:
- `<component>.imagePullSecrets` overrides everything
- otherwise falls back to `.Values.global.imagePullSecrets`
- accepts string, list, or `{name}` map

## Ingress Formats

Both formats are supported.

Map style:

```yaml
web:
  ingress:
    annotations:                    # shared by all entries below
      nginx.ingress.kubernetes.io/ssl-redirect: "true"
    external:
      domains:
        - app.example.com
      annotations:                  # entry-specific (mergeOverwrite)
        nginx.ingress.kubernetes.io/proxy-body-size: 64m
    internal:
      domains:
        - app.internal.example.com
```

List style:

```yaml
web:
  ingress:
    - name: public
      className: nginx
      domains:
        - app.example.com
    - name: private
      className: nginx-internal
      domains:
        - app.internal.example.com
```

Chart-wide ingress defaults can also be set under `global.ingress`:

```yaml
global:
  ingress:
    className: nginx
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
```

These are merged into every ingress entry (both styles); per-entry annotations
override.

## Hooks and Weights (ConfigMap / ExternalSecret)

```yaml
global:
  hooks:
    enabled: true                      # default: true
    preInstallEnvironments: [review]   # default
    weight: "-5"                       # helm.sh/hook-weight when hooks fire
```

Behavior:
- For environments listed in `preInstallEnvironments`, ConfigMaps and
  ExternalSecrets are emitted as `pre-install,pre-upgrade` Helm hooks.
- For other environments, when `.Values.werf` exists, `werf.io/weight` is set
  from `.Values.werf.configWeight` / `.Values.werf.secretWeight` (default `-1`).
- Set `global.hooks.enabled: false` to disable hook annotations entirely.

## Werf Compatibility

Werf annotations (`werf.io/no-activity-timeout`,
`werf.io/failures-allowed-per-replica`) and the `werf.io/replicas-on-creation`
annotation on Deployments are emitted only when **werf annotations are enabled**.

Resolution:
1. `.Values.global.werf.annotations` (boolean) -- explicit override
2. otherwise, automatically `true` when both `.Values.werf.name` and
   `.Values.werf.env` are set (preserves legacy behavior)
3. otherwise `false`

To override the deployment annotation key explicitly:

```yaml
global:
  deployment:
    replicasOnCreationAnnotation: "my.org/initial-replicas"
```

Empty string disables the annotation entirely.

## Selector Safety

`Deployment`, `StatefulSet`, `Service`, `PDB`, and `PodMonitor` selectors use
`common.labels.matchLabels`, which is the **minimum stable set**:

- `app.kubernetes.io/name`
- `app.kubernetes.io/component` (when component is set)
- `app.kubernetes.io/environment`
- `app.kubernetes.io/instance` (when release name is set)

`version` and any `extraLabels` are intentionally omitted -- selectors are
immutable on existing Deployments and StatefulSets, so the selector contents
must be stable across upgrades.

If migrating a chart whose pre-1.3 release stored `version` in the selector,
opt into the legacy shape:

```yaml
global:
  compat:
    legacySelectorLabels: true
```

This is a transitional knob; new charts should not set it.

## Reference

| Key | Default | Purpose |
|-----|---------|---------|
| `name` / `app.name` / `global.name` | `.Chart.Name` then `"app"` | App label |
| `environment` / `env` / `global.environment` / `global.env` | `"default"` | Env label |
| `global.image` | -- | Default image (string or map) |
| `global.imagePullPolicy` / `global.image.pullPolicy` | `IfNotPresent` | Default pull policy |
| `global.imagePullSecrets` | -- | Default pull secrets |
| `global.ingress.className` | per-style default (`nginx`/`nginx-internal`) | Default ingress class |
| `global.ingress.annotations` | `{}` | Annotations applied to every ingress |
| `global.pdb.maxUnavailable` | `25%` | Default PDB maxUnavailable |
| `global.hooks.enabled` | `true` | Enable hook annotations on configs/secrets |
| `global.hooks.preInstallEnvironments` | `[review]` | Envs that run as hooks |
| `global.hooks.weight` | `"-5"` | Hook weight |
| `global.deployment.replicasOnCreationAnnotation` | `""` (or `werf.io/replicas-on-creation` when werf enabled) | Initial-replicas annotation |
| `global.werf.annotations` | auto | Force werf annotations on/off |
| `global.compat.legacySelectorLabels` | `false` | Include version+extraLabels in selectors |
| `werf.name` / `werf.env` / `werf.image.app` | -- | Legacy fallbacks |
| `global.profile` | `rails` | Profile name (rails, generic, python, go). See profiles.md. |
| `nativeSecrets.<name>` | -- | Native K8s Secrets (chart.secret) |
| `prometheusRules.<name>` | -- | PrometheusRule entries (chart.prometheusrule) |
| `priorityClasses.<name>` | -- | PriorityClass entries (chart.priorityclass) |
| `triggerAuthentications.<name>` | -- | KEDA TriggerAuthentication entries |
| `networkPolicies.<name>` | -- | Top-level freeform NetworkPolicy entries |
| `rbac.<name>` | -- | Top-level freeform RBAC entries |
| `<component>.hpa` | -- | Native HorizontalPodAutoscaler |
| `<component>.vpa` | -- | VerticalPodAutoscaler |
| `<component>.daemonSet` | -- | DaemonSet-specific spec (used by chart.daemonset) |
| `<component>.serviceMonitor` | -- | Prometheus Operator ServiceMonitor |
| `<component>.networkPolicy` | -- | Per-component NetworkPolicy |
| `<component>.rbac` | -- | Per-component Role + RoleBinding |
| `<component>.rbacCluster` | -- | Per-component ClusterRole + ClusterRoleBinding |
| `<component>.revisionHistoryLimit` | -- | Deployment / StatefulSet / DaemonSet revisionHistoryLimit |
| `<component>.progressDeadlineSeconds` | -- | Deployment progressDeadlineSeconds |
| `<component>.paused` | -- | Deployment paused |
