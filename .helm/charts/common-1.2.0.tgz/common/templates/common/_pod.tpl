{{/*
=============================================================================
POD CONFIGURATION HELPERS
=============================================================================
*/}}

{{/*
Add node selector to pods if specified
Usage: {{ include "common.nodeSelector" .Values.myComponent }}
*/}}
{{- define "common.nodeSelector" }}
{{- if kindIs "map" . }}
{{- if hasKey . "nodeSelector" }}
nodeSelector: {{ toYaml .nodeSelector | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Add image pull secrets to pods if specified
Usage: {{ include "common.imagePullSecrets" .Values.myComponent }}
*/}}
{{- define "common.imagePullSecrets" }}
{{- if kindIs "map" . }}
{{- if hasKey . "imagePullSecrets" }}
imagePullSecrets:
{{- if kindIs "string" .imagePullSecrets }}
  - name: {{ .imagePullSecrets }}
{{- else if kindIs "slice" .imagePullSecrets }}
  {{ toYaml .imagePullSecrets | nindent 2 }}
{{- else }}
  - name: {{ .imagePullSecrets.name }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Add topology spread constraints to pods if specified
Usage: {{ include "common.topologySpreadConstraints" .Values.myComponent }}
*/}}
{{- define "common.topologySpreadConstraints" }}
{{- if kindIs "map" . }}
{{- if hasKey . "topologySpreadConstraints" }}
topologySpreadConstraints: {{ toYaml .topologySpreadConstraints | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Configure the priority class name for a pod
Usage: {{ include "common.priorityClassName" .Values.myComponent }}
*/}}
{{- define "common.priorityClassName" }}
{{- if kindIs "map" . }}
{{- if hasKey . "priorityClassName" }}
priorityClassName: {{ .priorityClassName }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Configure host aliases for a pod
Usage: {{ include "common.hostAliases" .Values.myComponent }}
*/}}
{{- define "common.hostAliases" }}
{{- if kindIs "map" . }}
{{- if hasKey . "hostAliases" }}
hostAliases: {{ toYaml .hostAliases | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Configure pod annotations
Usage: {{ include "common.podAnnotations" .Values.myComponent }}
*/}}
{{- define "common.podAnnotations" }}
{{- if kindIs "map" . }}
{{- if hasKey . "podAnnotations" }}
annotations: {{ toYaml .podAnnotations | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Configure init containers
Usage: {{ include "common.initContainers" .Values.myComponent }}
*/}}
{{- define "common.initContainers" }}
{{- if kindIs "map" . }}
{{- if hasKey . "initContainers" }}
initContainers:
  {{- if kindIs "slice" .initContainers }}
  {{ toYaml .initContainers | nindent 2 }}
  {{- else }}
  {{- if kindIs "map" .initContainers }}
  {{- range $name, $container := .initContainers }}
  - name: {{ $name }}
    {{ toYaml $container | nindent 4 }}
  {{- end }}
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}


{{/*
Set up service account for pods
Usage: {{ include "common.serviceAccount" .Values.myComponent }}
*/}}
{{- define "common.serviceAccount" }}
{{- if kindIs "map" . }}
{{- if hasKey . "serviceAccount" }}
serviceAccountName: {{ .serviceAccount.name }}
{{- else }}
serviceAccountName: "default"
{{- end }}
{{- end }}
{{- end }}

{{/*
Standard tolerations from global config
Usage: {{ include "common.tolerations" . }}
*/}}
{{- define "common.tolerations" }}
{{- if kindIs "map" . }}
{{- if hasKey . "tolerations" }}
tolerations:
{{- range .tolerations }}
  - key: {{ required "Toleration key is required" .key | toString | quote }}
    operator: {{ default "Equal" .operator | toString | quote }}
    value: {{ default "true" .value | toString | quote }}
    effect: {{ default "NoSchedule" .effect | toString | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Standard pod anti-affinity configuration to spread pods across zones and nodes
Usage: {{ include "common.podAntiAffinity" (dict "svc" "my-service" "cmp" "web" "env" "prod" "Values" .Values) }}
*/}}
{{- define "common.podAntiAffinity" }}
podAntiAffinity:
{{- if .val.default }}
  preferredDuringSchedulingIgnoredDuringExecution:
  - weight: 100
    podAffinityTerm:
      labelSelector:
        matchExpressions:
        - key: app.kubernetes.io/name
          operator: In
          values:
          - {{ .svc }}
        - key: app.kubernetes.io/component
          operator: In
          values:
          - {{ .cmp }}
        - key: app.kubernetes.io/environment
          operator: In
          values:
          - {{ .env }}
      topologyKey: topology.kubernetes.io/zone
  - weight: 99
    podAffinityTerm:
      labelSelector:
        matchExpressions:
        - key: app.kubernetes.io/name
          operator: In
          values:
          - {{ .svc }}
        - key: app.kubernetes.io/component
          operator: In
          values:
          - {{ .cmp }}
        - key: app.kubernetes.io/environment
          operator: In
          values:
          - {{ .env }}
      topologyKey: kubernetes.io/hostname
{{- end }}
{{ with .val.custom }}
  {{ toYaml . | nindent 2 }}
{{- end }}
{{- end }}

{{/*
Node affinity helper
Usage: {{ include "common.nodeAffinity" .Values.global.nodeAffinity }}
*/}}
{{- define "common.nodeAffinity" }}
nodeAffinity:
  requiredDuringSchedulingIgnoredDuringExecution:
    nodeSelectorTerms:
    {{- range . }}
      - matchExpressions:
          - key: {{ .key }}
            operator: {{ default "In" .operator }}
            values:
              - {{ .value }}
    {{- end }}
{{- end }}

{{/*
Combined affinity helper that includes both node and pod affinities
Usage: {{ include "common.affinity" . }}
*/}}
{{- define "common.affinity" }}
{{- $svc := .svc }}
{{- $cmp := .cmp }}
{{- $env := .env }}
{{- $val := .val }}
{{- if kindIs "map" $val }}
{{- with $val.affinity }}
affinity:
{{- with .nodeAffinity }}
{{ include "common.nodeAffinity" . | nindent 2 }}
{{- end }}
{{- with .podAntiAffinity }}
{{ include "common.podAntiAffinity" (dict "svc" $svc "cmp" $cmp "env" $env "val" .) | nindent 2 }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Pod security context that can be applied to all pods with intelligent defaults
Reads from .securityContext.pod if available, uses provided defaults if not
Usage:
- Simple: {{ include "common.pod.securityContext" . }}
- With overrides: {{ include "common.pod.securityContext" (dict "runAsUser" 1000 "runAsGroup" 3000) }}
*/}}
{{- define "common.pod.securityContext" }}
{{- $secCtx := dict }}
{{- $defaults := dict "runAsUser" 1000 "runAsGroup" 3000 "seccompType" "RuntimeDefault" }}

{{/* Get values from .securityContext.pod if available */}}
{{- if . }}
  {{- if kindIs "map" . }}
    {{- if hasKey . "securityContext" }}
      {{- if hasKey .securityContext "pod" }}
        {{- $secCtx = .securityContext.pod }}
      {{- end }}
    {{- end }}
  {{- end }}
{{- end }}

securityContext:
  {{/* runAsUser with proper fallbacks */}}
  runAsUser: {{ default (default $defaults.runAsUser $secCtx.runAsUser) .runAsUser }}

  {{/* runAsGroup with proper fallbacks */}}
  runAsGroup: {{ default (default $defaults.runAsGroup $secCtx.runAsGroup) .runAsGroup }}

  {{/* fsGroup with fallbacks */}}
  {{- $fsGroup := default $secCtx.fsGroup .fsGroup }}
  {{- if $fsGroup }}
  fsGroup: {{ $fsGroup }}
  {{- end }}

  {{/* seccompProfile with fallbacks */}}
  seccompProfile:
    type: {{ default (default $defaults.seccompType $secCtx.seccompType) .seccompType }}
{{- end }}

{{/*
Process and render volumes for pods
Supports multiple volume types: pvc, secret, config, emptyDir, hostPath, csi
Usage: {{ include "common.volumes" .Values.myComponent }}
*/}}
{{- define "common.volumes" }}
{{- if kindIs "map" . }}
volumes:
{{- if hasKey . "volumes" }}
{{- range $volume := .volumes }}
  - name: {{ $volume.name }}
{{- if eq (default "pvc" $volume.type) "pvc" }}
    persistentVolumeClaim:
      claimName: {{ default $volume.name $volume.claimName }}
{{- else if eq $volume.type "secret" }}
    secret:
      secretName: {{ $volume.secretName }}
      {{- if hasKey $volume "items" }}
      items:
      {{- range $item := $volume.items }}
        - key: {{ $item.key }}
          path: {{ $item.path }}
          {{- if hasKey $item "mode" }}
          mode: {{ $item.mode }}
          {{- end }}
      {{- end }}
      {{- end }}
      {{- if hasKey $volume "optional" }}
      optional: {{ $volume.optional }}
      {{- end }}
{{- else if eq $volume.type "config" }}
    configMap:
      name: {{ $volume.configMapName }}
      {{- if hasKey $volume "items" }}
      items:
      {{- range $item := $volume.items }}
        - key: {{ $item.key }}
          path: {{ $item.path }}
          {{- if hasKey $item "mode" }}
          mode: {{ $item.mode }}
          {{- end }}
      {{- end }}
      {{- end }}
      {{- if hasKey $volume "optional" }}
      optional: {{ $volume.optional }}
      {{- end }}
{{- else if eq $volume.type "emptyDir" }}
    emptyDir:
      {{- if hasKey $volume "medium" }}
      medium: {{ $volume.medium }}
      {{- end }}
      {{- if hasKey $volume "sizeLimit" }}
      sizeLimit: {{ $volume.sizeLimit }}
      {{- end }}
{{- else if eq $volume.type "hostPath" }}
    hostPath:
      path: {{ required "hostPath path is required" $volume.hostPath }}
      {{- with $volume.hostPathType }}
      type: {{ . }}
      {{- end }}
{{- else if eq $volume.type "csi" }}
    csi:
      driver: {{ required "CSI driver is required" $volume.csiDriver }}
      {{- with $volume.readOnly }}
      readOnly: {{ . }}
      {{- end }}
      {{- with $volume.fsType }}
      fsType: {{ . }}
      {{- end }}
      {{- with $volume.volumeAttributes }}
      volumeAttributes: {{ toYaml . | nindent 8 }}
      {{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- if hasKey . "persistence" }}
{{- $persistence := .persistence }}
{{- if kindIs "map" $persistence }}
  - name: {{ default "data" $persistence.name }}
    persistentVolumeClaim:
      claimName: {{ default $persistence.name $persistence.claimName }}
{{- else if kindIs "slice" $persistence }}
{{- range $pvc := $persistence }}
  - name: {{ required "PVC name is required" $pvc.name }}
    persistentVolumeClaim:
      claimName: {{ default $pvc.name $pvc.claimName }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
