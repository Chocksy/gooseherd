{{/*
=============================================================================
CRONJOB TEMPLATE
This template renders a Kubernetes CronJob with standard configuration.
=============================================================================
*/}}

{{- define "chart.cronjob" -}}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $componentValues := index .Values.cronjobs (.cmp | replace "-" "_") }}

apiVersion: batch/v1
kind: CronJob
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $componentValues | nindent 4 }}
spec:
  schedule: {{ (required "Schedule expression is required" $componentValues.schedule) | quote }}
  concurrencyPolicy: {{ default "Forbid" $componentValues.concurrencyPolicy | quote }}
  successfulJobsHistoryLimit: {{ default 1 $componentValues.successfulJobsHistoryLimit | int }}
  failedJobsHistoryLimit: {{ default 1 $componentValues.failedJobsHistoryLimit | int }}
  {{- with $componentValues.startingDeadlineSeconds }}
  startingDeadlineSeconds: {{ . }}
  {{- end }}
  {{- with $componentValues.suspend }}
  suspend: {{ . }}
  {{- end }}
  {{- with $componentValues.timeZone }}
  timeZone: {{ . | quote }}
  {{- end }}
  jobTemplate:
    spec:
      {{- with $componentValues.activeDeadlineSeconds }}
      activeDeadlineSeconds: {{ . }}
      {{- end }}
      backoffLimit: {{ default 0 $componentValues.backoffLimit | int }}
      {{- with $componentValues.ttlSecondsAfterFinished }}
      ttlSecondsAfterFinished: {{ . }}
      {{- end }}
      template:
        metadata:
          labels: {{ include "common.labels" . | nindent 12 }}
          {{- include "common.podAnnotations" $componentValues | nindent 10 }}
        spec:
          {{ include "common.workload.podSpec" (dict
            "root" $
            "component" $componentValues
            "svc" $svc
            "cmp" $cmp
            "env" $env
            "restartPolicy" (default "Never" $componentValues.restartPolicy)
          ) | nindent 10 }}
{{- end -}}
