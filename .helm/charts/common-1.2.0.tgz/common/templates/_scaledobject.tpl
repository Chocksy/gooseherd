{{/*
=============================================================================
SCALEDOBJECT TEMPLATE
This template renders a KEDA ScaledObject for autoscaling Kubernetes resources.
=============================================================================
*/}}

{{- define "chart.scaledobject" }}
{{- $componentPath := (.cmp | replace "-" "_") }}
{{- if hasKey .Values $componentPath }}
{{- $componentValues := index .Values $componentPath }}
{{- if $componentValues.scaling }}
---
{{- $svc := default .Values.werf.name .svc }}
{{- $cmp := (required "Component name is required" .cmp) | replace "_" "-" }}
{{- $env := (required "Environment is required" .Values.werf.env) }}
{{- $scaleConfig := $componentValues.scaling }}

apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: {{ $cmp }}
  labels: {{ include "common.labels" . | nindent 4 }}
  {{ include "common.annotations" $scaleConfig | nindent 4 }}
spec:
  scaleTargetRef:
    name: {{ $cmp }}
    {{- with $scaleConfig.apiVersion }}
    apiVersion: {{ . }}
    {{- end }}
    {{- with $scaleConfig.kind }}
    kind: {{ . }}
    {{- else }}
    kind: Deployment
    {{- end }}
  pollingInterval: {{ default 30 $scaleConfig.pollingInterval }}
  cooldownPeriod: {{ default 180 $scaleConfig.cooldownPeriod }}
  minReplicaCount: {{ default 1 $scaleConfig.min }}
  maxReplicaCount: {{ default 1 $scaleConfig.max }}
  {{- with $scaleConfig.idleReplicaCount }}
  idleReplicaCount: {{ . }}
  {{- end }}
  advanced:
    {{- with $scaleConfig.horizontalPodAutoscalerConfig }}
    horizontalPodAutoscalerConfig: {{ toYaml . | nindent 6 }}
    {{- end }}
    restoreToOriginalReplicaCount: {{ default false $scaleConfig.restoreToOriginalReplicaCount }}
    {{- with $scaleConfig.scalingModifiers }}
    scalingModifiers: {{ toYaml . | nindent 6 }}
    {{- end }}
  fallback:
    failureThreshold: {{ default 3 $scaleConfig.failureThreshold }}
    replicas: {{ default 1 $scaleConfig.fallback }}
  triggers:
  {{- range $scaleConfig.triggers }}
  {{- if eq .type "cron" }}
    - type: cron
      metadata:
        timezone: {{ default "Etc/UTC" .timezone | quote }}
        start: {{ .start | quote }}
        end: {{ .stop | quote }}
        desiredReplicas: {{ .desiredReplicas | quote }}
  {{- else if eq .type "prometheus" }}
    - type: prometheus
      metadata:
        serverAddress: {{ default "http://prometheus-prometheus.prometheus.svc.cluster.local:9090" $.Values.global.prometheusEndpoint }}
        threshold: {{ .threshold | quote }}
        query: {{ tpl .query $ | quote }}
        {{- with .authModes }}
        authModes: {{ . | quote }}
        {{- end }}
        {{- with .unsafeSsl }}
        unsafeSsl: {{ . | quote }}
        {{- end }}
        {{- with .ignoreNullValues }}
        ignoreNullValues: {{ . | quote }}
        {{- end }}
  {{- else if eq .type "redis" }}
    - type: redis
      metadata:
        listName: {{ .listName | quote }}
        listLength: {{ .listLength | quote }}
        addressFromEnv: {{ default "REDIS_HOST" .hostEnv | quote }}
        enableTLS: {{ default "true" .enableTLS }}
        usernameFromEnv: {{ default "REDIS_USERNAME" .usernameEnv | quote }}
        passwordFromEnv: {{ default "REDIS_PASSWORD" .passwordEnv | quote }}
        {{- with .dbIndex }}
        dbIndex: {{ . | quote }}
        {{- end }}
  {{- else if eq .type "cpu" }}
    - type: cpu
      metadata:
        value: {{ .value | quote }}
  {{- else if eq .type "memory" }}
    - type: memory
      metadata:
        value: {{ .value | quote }}
  {{- else if eq .type "kafka" }}
    - type: kafka
      metadata:
        bootstrapServers: {{ .bootstrapServers | quote }}
        consumerGroup: {{ .consumerGroup | quote }}
        topic: {{ .topic | quote }}
        lagThreshold: {{ .lagThreshold | quote }}
        {{- with .offsetResetPolicy }}
        offsetResetPolicy: {{ . | quote }}
        {{- end }}
  {{- else if eq .type "rabbitmq" }}
    - type: rabbitmq
      metadata:
        queueName: {{ .queueName | quote }}
        host: {{ .host | quote }}
        {{- with .queueLength }}
        queueLength: {{ . | quote }}
        {{- end }}
        {{- with .vhostName }}
        vhostName: {{ . | quote }}
        {{- end }}
  {{- else }}
    - type: {{ .type }}
      metadata:
      {{- range $key, $value := .metadata }}
        {{ $key }}: {{ $value | quote }}
      {{- end }}
  {{- end }}
  {{- with .authenticationRef }}
    authenticationRef: {{ toYaml . | nindent 6 }}
  {{- end }}
  {{- with .metadata }}
    metadata: {{ toYaml . | nindent 6 }}
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}
{{- end }}
