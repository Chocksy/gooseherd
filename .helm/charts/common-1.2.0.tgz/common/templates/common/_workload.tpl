{{/*
=============================================================================
WORKLOAD POD SPEC HELPERS
Shared helpers to render pod specs consistently across workload types.
=============================================================================
*/}}

{{/*
Render a full pod spec body for a workload.
Usage:
{{ include "common.workload.podSpec" (dict
  "root" $
  "component" $componentValues
  "svc" $svc
  "cmp" $cmp
  "env" $env
  "includePorts" true
  "includeProbes" true
  "includeLifecycle" true
  "includePriorityClassName" true
  "includeHostAliases" true
  "includeTopologySpreadConstraints" true
  "includeTerminationGracePeriod" true
) }}
*/}}
{{- define "common.workload.podSpec" }}
{{- $root := .root }}
{{- $component := .component }}
{{- $svc := .svc }}
{{- $cmp := .cmp }}
{{- $env := .env }}

{{- $includePorts := default false .includePorts }}
{{- $includeProbes := default false .includeProbes }}
{{- $includeLifecycle := default false .includeLifecycle }}
{{- $includePriorityClassName := default false .includePriorityClassName }}
{{- $includeHostAliases := default false .includeHostAliases }}
{{- $includeTopologySpreadConstraints := default false .includeTopologySpreadConstraints }}
{{- $includeTerminationGracePeriod := default false .includeTerminationGracePeriod }}

{{- if $includePriorityClassName }}
{{ include "common.priorityClassName" $component }}
{{- end }}
{{- if $includeHostAliases }}
{{ include "common.hostAliases" $component }}
{{- end }}
containers:
  - name: {{ $cmp }}
    image: {{ $root.Values.werf.image.app }}
    imagePullPolicy: {{ default "IfNotPresent" $component.imagePullPolicy | quote }}
    {{ include "common.command" $component | nindent 4 }}
    {{ include "common.args" $component | nindent 4 }}
    {{- if $includePorts }}
    {{ include "common.ports" $component | nindent 4 }}
    {{- end }}
    {{ include "common.envFrom" (dict "svc" $component "global" $root.Values.global) | nindent 4 }}
    {{ include "common.envs" $component | nindent 4 }}
    {{ include "common.resources" $component | nindent 4 }}
    {{- if $includeProbes }}
    {{ include "common.probes" $component | nindent 4 }}
    {{- end }}
    {{ include "common.container.securityContext" $component | nindent 4 }}
    {{- if $includeLifecycle }}
    {{ include "common.lifecycle" $component | nindent 4 }}
    {{- end }}
    {{ include "common.volumeMounts" $component | nindent 4 }}
    {{- with $component.extraContainerConfig }}
    {{ toYaml . | nindent 4 }}
    {{- end }}
{{ include "common.initContainers" $component }}
{{- with .restartPolicy }}
restartPolicy: {{ . | quote }}
{{- end }}
{{- if $includeTerminationGracePeriod }}
terminationGracePeriodSeconds: {{ default 30 $component.terminationGracePeriod }}
{{- end }}
{{ include "common.pod.securityContext" $component }}
{{ include "common.tolerations" $component }}
{{ include "common.affinity" (dict "val" $component "svc" $svc "cmp" $cmp "env" $env) }}
{{ include "common.serviceAccount" $component }}
{{ include "common.volumes" $component }}
{{ include "common.nodeSelector" $component }}
{{ include "common.imagePullSecrets" $component }}
{{- if $includeTopologySpreadConstraints }}
{{ include "common.topologySpreadConstraints" $component }}
{{- end }}
{{- with $component.extraPodConfig }}
{{ toYaml . }}
{{- end }}
{{- end }}
